# Polymarket Auto-Redeem v3 💰🦊

A Chrome extension that connects to MetaMask, monitors your Polymarket positions via their API in the background, and auto-redeems your winnings.

## Architecture

```
┌────────────────────────────────────────────────────────────┐
│                   MetaMask Connection                       │
│                                                             │
│  Opens a tab → requests wallet → signs EIP-712 message      │
│  → obtains CLOB API credentials → stores locally            │
└──────────────────────┬─────────────────────────────────────┘
                       │
┌──────────────────────▼─────────────────────────────────────┐
│              Background Service Worker                      │
│                                                             │
│  Every 5 min (no open tab needed):                          │
│  1. Query Gamma API / CLOB API with wallet address          │
│  2. Find resolved markets with unredeemed shares            │
│  3. Notify if winnings found                                │
│  4. If auto-redeem ON → open PM tab → content script        │
└──────────────────────┬─────────────────────────────────────┘
                       │ when redeeming
┌──────────────────────▼─────────────────────────────────────┐
│     Content Script (polymarket.com only)                     │
│                                                             │
│  Clicks "Redeem" buttons → confirms dialogs                 │
│  (Redemption = on-chain tx via PM's Safe relay)             │
└────────────────────────────────────────────────────────────┘
```

## Why MetaMask?

Polymarket's CLOB API uses **EIP-712 signed messages** for authentication. By connecting MetaMask:

- **Auto-detects your wallet address** — no manual copy-paste
- **Signs the Polymarket auth message** — generates read-only API credentials
- **More reliable position detection** — authenticated API access returns richer data
- **Your private key never leaves MetaMask** — we only store the API credentials (apiKey, secret, passphrase)

## Installation

1. Unzip the extension
2. `chrome://extensions/` → **Developer mode** ON → **Load unpacked**
3. Click the extension icon → **Connect MetaMask**
4. Approve the wallet connection and sign the auth message
5. Done! Background monitoring starts immediately

## How Redemption Works

> **Important**: Polymarket uses Gnosis Safe proxy wallets. Redemption requires calling
> `redeemPositions` on the Conditional Tokens contract *through* your Safe wallet.
> There is currently no API endpoint for this — it must go through the Polymarket web UI,
> which handles the Safe transaction relay.

When the extension detects redeemable positions, it:
1. Opens `polymarket.com/portfolio` in a background tab
2. The content script finds "Redeem" buttons and clicks them
3. Polymarket's frontend handles the on-chain transaction via their relay
4. The extension reports success/failure

## Settings

| Setting | Description | Default |
|---------|-------------|---------|
| Background Monitoring | Poll Polymarket API every 5 min | ✅ On |
| Auto-Redeem | Open PM and click Redeem automatically | ❌ Off |
| Notifications | Desktop alerts for new winnings | ✅ On |

## Privacy & Security

- **Private key**: Never accessed, never stored. Stays in MetaMask.
- **API credentials**: Stored locally in Chrome extension storage. Used for read-only API access.
- **Wallet address**: Public blockchain data, no security risk.
- **The EIP-712 signature** only proves wallet ownership to Polymarket's API — it cannot move funds.

## Manual Mode

If you don't want to use MetaMask, you can paste your wallet address manually in the popup. You'll still get background position monitoring, but without L1 API authentication (falls back to public Gamma API endpoints).

## Troubleshooting

| Issue | Fix |
|-------|-----|
| MetaMask not detected | Install MetaMask, refresh the connection page |
| 0 positions found | Verify your wallet address matches your Polymarket profile |
| Auto-redeem not working | PM may have changed their UI. Use manual redeem on their portfolio page |
| API auth failed | Reconnect MetaMask and re-sign the auth message |
