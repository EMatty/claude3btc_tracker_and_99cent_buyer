// Polymarket API Client — fetches positions via Gamma API + CLOB API
// Works from the service worker (no DOM/window.ethereum needed)

const GAMMA = 'https://gamma-api.polymarket.com';
const CLOB = 'https://clob.polymarket.com';

// ============================================================================
// Fetch positions — tries multiple endpoints, returns unified format
// ============================================================================
export async function fetchPositions(walletAddress, apiCreds) {
  const addr = walletAddress.toLowerCase();
  let positions = [];

  // ---- Method 1: Gamma API profile positions ----
  positions = await tryGammaPositions(addr);
  if (positions.length > 0) return positions;

  // ---- Method 2: Gamma API /users endpoint ----
  positions = await tryGammaUsersPositions(addr);
  if (positions.length > 0) return positions;

  // ---- Method 3: CLOB API with L2 creds (if available) ----
  if (apiCreds?.apiKey) {
    positions = await tryClobPositions(addr, apiCreds);
    if (positions.length > 0) return positions;
  }

  // ---- Method 4: Data API ----
  positions = await tryDataApi(addr);

  return positions;
}

async function tryGammaPositions(addr) {
  try {
    // Try the standard positions endpoint
    const res = await fetch(`${GAMMA}/positions?user=${addr}&limit=500&sizeThreshold=0`);
    if (!res.ok) return [];
    const data = await res.json();
    if (!Array.isArray(data)) return [];
    return data.map(normalizeGammaPosition);
  } catch (e) {
    console.warn('[API] Gamma positions error:', e.message);
    return [];
  }
}

async function tryGammaUsersPositions(addr) {
  try {
    const res = await fetch(`${GAMMA}/users/positions?id=${addr}&limit=500`);
    if (!res.ok) return [];
    const data = await res.json();
    const list = data?.positions || data;
    if (!Array.isArray(list)) return [];
    return list.map(normalizeGammaPosition);
  } catch (e) {
    console.warn('[API] Gamma users error:', e.message);
    return [];
  }
}

async function tryClobPositions(addr, creds) {
  try {
    // L2 auth headers would need HMAC signing which is complex
    // For now, try simple auth
    const res = await fetch(`${CLOB}/positions?user=${addr}`, {
      headers: { 'Authorization': `Bearer ${creds.apiKey}` },
    });
    if (!res.ok) return [];
    const data = await res.json();
    if (!Array.isArray(data)) return [];
    return data.map(p => ({
      id: p.asset || p.conditionId || p.id,
      conditionId: p.conditionId,
      tokenId: p.asset,
      marketSlug: p.slug || '',
      marketTitle: p.title || p.question || 'Unknown',
      outcome: p.outcome || (p.outcomeIndex === 0 ? 'Yes' : 'No'),
      size: parseFloat(p.size || 0),
      avgPrice: parseFloat(p.avgPrice || 0),
      currentPrice: parseFloat(p.curPrice || p.currentPrice || 0),
      resolved: !!p.resolved,
      redeemable: !!p.redeemable,
      payout: parseFloat(p.payout || 0),
      marketUrl: p.slug ? `https://polymarket.com/event/${p.slug}` : '',
    }));
  } catch (e) {
    console.warn('[API] CLOB positions error:', e.message);
    return [];
  }
}

async function tryDataApi(addr) {
  try {
    const res = await fetch(`https://data-api.polymarket.com/positions?user=${addr}&sizeThreshold=0`);
    if (!res.ok) return [];
    const data = await res.json();
    if (!Array.isArray(data)) return [];
    return data.map(normalizeGammaPosition);
  } catch (e) {
    console.warn('[API] Data API error:', e.message);
    return [];
  }
}

function normalizeGammaPosition(p) {
  const resolved = !!(p.resolved || p.curPrice === 0 || p.curPrice === 1);
  const payout = parseFloat(p.payout || p.cashPayout || 0);
  const size = parseFloat(p.size || p.currentValue || p.initialValue || 0);
  const redeemable = !!(p.redeemable || (p.resolved && (payout > 0 || p.cashPayout > 0)));

  return {
    id: p.conditionId || p.id || '',
    conditionId: p.conditionId || '',
    tokenId: p.asset || '',
    marketSlug: p.marketSlug || p.slug || '',
    marketTitle: p.title || p.question || p.eventTitle || 'Unknown Market',
    outcome: p.outcome || p.outcomeName || '',
    size,
    avgPrice: parseFloat(p.avgPrice || 0),
    currentPrice: parseFloat(p.curPrice || p.currentPrice || 0),
    resolved,
    redeemable,
    payout: payout > 0 ? payout : (redeemable ? size : 0),
    marketUrl: p.marketSlug
      ? `https://polymarket.com/event/${p.marketSlug}`
      : '',
  };
}

// ============================================================================
// Get only redeemable positions
// ============================================================================
export async function getRedeemablePositions(walletAddress, apiCreds) {
  const all = await fetchPositions(walletAddress, apiCreds);

  const redeemable = all.filter(p =>
    p.redeemable ||
    (p.resolved && p.payout > 0.001) ||
    (p.resolved && p.size > 0.01)
  );

  return {
    all,
    redeemable,
    totalRedeemableValue: redeemable.reduce((s, p) => s + (p.payout || p.size || 0), 0),
  };
}
