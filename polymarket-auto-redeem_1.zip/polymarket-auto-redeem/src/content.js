// Polymarket Auto-Redeem v3 — Content Script
// Runs on polymarket.com. Handles DOM-based redemption when triggered.

(function () {
  'use strict';
  let busy = false;

  function findRedeemButtons() {
    const btns = [];
    const seen = new Set();
    document.querySelectorAll('button, [role="button"]').forEach(el => {
      if (seen.has(el)) return;
      const t = el.textContent.trim().toLowerCase();
      if ((t.includes('redeem') || t.includes('claim')) && !t.includes('redeemed') && !t.includes('claimed') && !el.disabled && el.offsetParent !== null) {
        btns.push(el);
        seen.add(el);
      }
    });
    return btns;
  }

  function extractInfo(btn) {
    let box = btn.closest('[class*="position"],[class*="card"],[class*="row"],[class*="market"],tr,li,article') || btn.parentElement?.parentElement;
    const h = box?.querySelector('h1,h2,h3,h4,h5,h6,[class*="title"],[class*="question"],p');
    const name = h?.textContent?.trim() || 'Unknown';
    const m = (box?.textContent || '').match(/\$\s*([\d,.]+)/);
    const val = m ? parseFloat(m[1].replace(/,/g, '')) : 0;
    return { marketName: name, value: val };
  }

  function findConfirm() {
    for (const modal of document.querySelectorAll('[class*="modal"],[class*="dialog"],[role="dialog"],[class*="overlay"]')) {
      for (const b of modal.querySelectorAll('button,[role="button"]')) {
        const t = b.textContent.trim().toLowerCase();
        if ((t.includes('confirm') || t === 'redeem' || t === 'claim') && !b.disabled) return b;
      }
    }
    return null;
  }

  async function redeemAll() {
    if (busy) return;
    busy = true;
    try {
      const btns = findRedeemButtons();
      if (!btns.length) { toast('No redeem buttons found on page', 'info'); return; }
      toast(`Redeeming ${btns.length} position${btns.length > 1 ? 's' : ''}...`, 'info');

      for (const btn of btns) {
        try {
          const info = extractInfo(btn);
          btn.scrollIntoView({ behavior: 'smooth', block: 'center' });
          await sleep(400);
          btn.click();
          await sleep(2000);
          const cf = findConfirm();
          if (cf) { cf.click(); await sleep(3000); }
          await sleep(1500);
          chrome.runtime.sendMessage({ action: 'redeemResult', result: { market: info.marketName, value: info.value, status: 'success' } });
          toast(`✓ ${info.marketName} ($${info.value.toFixed(2)})`, 'success');
        } catch (e) {
          chrome.runtime.sendMessage({ action: 'redeemResult', result: { market: 'Unknown', value: 0, status: 'error', error: e.message } });
          toast('✗ Failed, trying next...', 'error');
        }
      }
      toast('✓ All done!', 'success');
      chrome.runtime.sendMessage({ action: 'forceCheck' });
    } finally { busy = false; }
  }

  function scanAndReport() {
    const btns = findRedeemButtons();
    const positions = btns.map(b => extractInfo(b));
    const totalValue = positions.reduce((s, p) => s + p.value, 0);
    chrome.runtime.sendMessage({ action: 'redeemableFound', count: btns.length, totalValue, positions });
    showBadge(btns.length, totalValue);
  }

  // ---- Floating badge ----
  function showBadge(count, val) {
    let el = document.getElementById('pm-ar-badge');
    if (!count) { el?.remove(); return; }
    if (!el) { el = document.createElement('div'); el.id = 'pm-ar-badge'; document.body.appendChild(el); }
    el.innerHTML = `<div class="pm-ar-inner"><span class="pm-ar-e">💰</span><div class="pm-ar-txt"><strong>${count}</strong> to redeem · <span class="pm-ar-g">~$${val.toFixed(2)}</span></div><button id="pm-ar-go">Redeem All</button></div>`;
    document.getElementById('pm-ar-go')?.addEventListener('click', () => { document.getElementById('pm-ar-go').textContent = 'Working...'; redeemAll(); });
  }

  // ---- Toast ----
  function toast(msg, type = 'info') {
    let c = document.getElementById('pm-ar-toasts');
    if (!c) { c = document.createElement('div'); c.id = 'pm-ar-toasts'; document.body.appendChild(c); }
    const t = document.createElement('div');
    t.className = `pm-ar-toast pm-ar-toast--${type}`;
    t.textContent = msg;
    c.appendChild(t);
    requestAnimationFrame(() => t.classList.add('visible'));
    setTimeout(() => { t.classList.remove('visible'); setTimeout(() => t.remove(), 300); }, 4000);
  }

  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // ---- Messages ----
  chrome.runtime.onMessage.addListener((msg, _, res) => {
    if (msg.action === 'redeemAll') { redeemAll().then(() => res({ ok: true })); return true; }
    if (msg.action === 'scan' || msg.action === 'checkRedeemable') { scanAndReport(); res({ ok: true }); return true; }
  });

  // Auto-scan
  setTimeout(scanAndReport, 3000);
  let lastUrl = location.href;
  new MutationObserver(() => { if (location.href !== lastUrl) { lastUrl = location.href; setTimeout(scanAndReport, 3000); } }).observe(document.body, { childList: true, subtree: true });

  console.log('[AutoRedeem] Content script v3 loaded');
})();
