// Polymarket Auto-Redeem v3 — Background Service Worker
// Monitors positions via API; uses MetaMask auth for wallet detection

import { getRedeemablePositions } from './api.js';

const DEFAULTS = {
  enabled: true,
  autoRedeem: false,
  notifications: true,
  walletAddress: '',
  walletConnected: false,
  apiCreds: null,
  checkIntervalMinutes: 5,
};

// ============================================================================
// LIFECYCLE
// ============================================================================
chrome.runtime.onInstalled.addListener(async () => {
  const data = await chrome.storage.local.get(null);
  await chrome.storage.local.set({ ...DEFAULTS, ...data, installedAt: data.installedAt || Date.now() });
  setupAlarm();
  console.log('[AR] Installed');
});

chrome.runtime.onStartup.addListener(() => {
  setupAlarm();
  console.log('[AR] Startup');
});

function setupAlarm() {
  chrome.alarms.create('checkPositions', { periodInMinutes: 5 });
  chrome.alarms.create('initialCheck', { delayInMinutes: 0.2 });
}

// ============================================================================
// PERIODIC CHECK
// ============================================================================
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'checkPositions' || alarm.name === 'initialCheck') {
    await runCheck();
  }
});

async function runCheck() {
  const s = await getSettings();
  if (!s.enabled || !s.walletAddress) {
    updateBadge(0);
    return;
  }

  try {
    console.log('[AR] Checking positions for', s.walletAddress);
    const result = await getRedeemablePositions(s.walletAddress, s.apiCreds);
    const { redeemable, totalRedeemableValue, all } = result;

    await chrome.storage.local.set({
      redeemableCount: redeemable.length,
      redeemableTotalValue: totalRedeemableValue,
      positions: redeemable,
      allPositions: all,
      totalPositions: all.length,
      lastChecked: Date.now(),
      lastError: null,
    });

    updateBadge(redeemable.length);

    // Notify
    if (redeemable.length > 0 && s.notifications) {
      const prev = s.redeemableCount || 0;
      if (redeemable.length > prev) {
        chrome.notifications.create('redeemable-' + Date.now(), {
          type: 'basic',
          iconUrl: 'icons/icon128.png',
          title: '💰 Winnings Available!',
          message: `${redeemable.length} position${redeemable.length !== 1 ? 's' : ''} worth ~$${totalRedeemableValue.toFixed(2)} ready to redeem.`,
        });
      }
    }

    // Auto-redeem
    if (s.autoRedeem && redeemable.length > 0) {
      await triggerRedemption(redeemable);
    }

    console.log(`[AR] Found ${redeemable.length} redeemable ($${totalRedeemableValue.toFixed(2)}) out of ${all.length} total`);
  } catch (err) {
    console.error('[AR] Check failed:', err);
    await chrome.storage.local.set({ lastError: err.message, lastChecked: Date.now() });
  }
}

// ============================================================================
// REDEMPTION — opens PM portfolio and lets content script click buttons
// ============================================================================
async function triggerRedemption(positions) {
  if (!positions?.length) return;
  const url = 'https://polymarket.com/portfolio';

  try {
    let tabs = await chrome.tabs.query({ url: 'https://polymarket.com/*' });
    let tab;

    if (tabs.length > 0) {
      tab = tabs[0];
      if (!tab.url.includes('/portfolio')) {
        await chrome.tabs.update(tab.id, { url });
      }
    } else {
      tab = await chrome.tabs.create({ url, active: false });
    }

    // Wait for load
    await new Promise(resolve => {
      const onUpdate = (id, info) => {
        if (id === tab.id && info.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(onUpdate);
          resolve();
        }
      };
      chrome.tabs.onUpdated.addListener(onUpdate);
      setTimeout(() => { chrome.tabs.onUpdated.removeListener(onUpdate); resolve(); }, 30000);
    });

    // Let SPA hydrate
    await new Promise(r => setTimeout(r, 5000));

    chrome.tabs.sendMessage(tab.id, { action: 'redeemAll', positions }).catch(() => {});
  } catch (err) {
    console.error('[AR] Redemption trigger failed:', err);
  }
}

// ============================================================================
// BADGE
// ============================================================================
function updateBadge(count) {
  chrome.action.setBadgeText({ text: count > 0 ? String(count) : '' });
  chrome.action.setBadgeBackgroundColor({ color: count > 0 ? '#00D395' : '#666' });
}

// ============================================================================
// MESSAGE BUS
// ============================================================================
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    switch (msg.action) {
      case 'getSettings':
        sendResponse(await getSettings());
        break;

      case 'updateSettings':
        await chrome.storage.local.set(msg.settings);
        if (msg.settings.walletAddress) runCheck();
        sendResponse({ ok: true });
        break;

      case 'walletConnected':
        await chrome.storage.local.set(msg.data);
        runCheck();
        sendResponse({ ok: true });
        break;

      case 'forceCheck':
        await runCheck();
        sendResponse({ ok: true });
        break;

      case 'triggerRedeem': {
        const s = await getSettings();
        await triggerRedemption(s.positions || []);
        sendResponse({ ok: true });
        break;
      }

      case 'openMetaMaskConnect':
        chrome.tabs.create({ url: chrome.runtime.getURL('src/metamask-connect.html') });
        sendResponse({ ok: true });
        break;

      case 'disconnect':
        await chrome.storage.local.set({
          walletAddress: '',
          walletConnected: false,
          apiCreds: null,
          hasApiCreds: false,
          authSignature: '',
          redeemableCount: 0,
          redeemableTotalValue: 0,
          positions: [],
          allPositions: [],
          totalPositions: 0,
        });
        updateBadge(0);
        sendResponse({ ok: true });
        break;

      case 'redeemResult':
        chrome.storage.local.get(['redeemHistory'], (data) => {
          const h = data.redeemHistory || [];
          h.unshift({ ...msg.result, timestamp: Date.now() });
          chrome.storage.local.set({ redeemHistory: h.slice(0, 100) });
        });
        sendResponse({ ok: true });
        break;

      case 'redeemableFound': {
        const { count, totalValue, positions } = msg;
        await chrome.storage.local.set({
          redeemableCount: count,
          redeemableTotalValue: totalValue,
          positions: positions || [],
          lastChecked: Date.now(),
        });
        updateBadge(count);
        sendResponse({ ok: true });
        break;
      }

      default:
        sendResponse({ error: 'unknown action' });
    }
  })();
  return true; // async
});

// Notification clicks
chrome.notifications.onClicked.addListener((id) => {
  if (id.startsWith('redeemable')) {
    chrome.tabs.create({ url: 'https://polymarket.com/portfolio' });
  }
});

// ============================================================================
// UTIL
// ============================================================================
async function getSettings() {
  return new Promise(r => chrome.storage.local.get(null, d => r({ ...DEFAULTS, ...d })));
}

console.log('[AR] Background loaded (v3 — MetaMask auth)');
