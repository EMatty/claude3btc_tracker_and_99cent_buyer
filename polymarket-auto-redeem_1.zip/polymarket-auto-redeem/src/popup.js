document.addEventListener('DOMContentLoaded', async () => {
  const $ = id => document.getElementById(id);

  // Views
  const notConnected = $('notConnected');
  const connected    = $('connected');

  // Controls
  const connectBtn   = $('connectBtn');
  const manualAddr   = $('manualAddr');
  const manualSaveBtn = $('manualSaveBtn');
  const disconnectBtn = $('disconnectBtn');
  const walletDisplay = $('walletDisplay');
  const statusPill   = $('statusPill');
  const statusText   = $('statusText');
  const totalPos     = $('totalPos');
  const redeemCnt    = $('redeemCnt');
  const redeemVal    = $('redeemVal');
  const togEnabled   = $('togEnabled');
  const togAutoRedeem = $('togAutoRedeem');
  const togNotify    = $('togNotify');
  const redeemBtn    = $('redeemBtn');
  const checkBtn     = $('checkBtn');
  const posList      = $('posList');
  const histSection  = $('histSection');
  const histList     = $('histList');
  const lastChecked  = $('lastChecked');

  // ---- Load ----
  let s = await load();
  render(s);

  // ---- MetaMask connect ----
  connectBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'openMetaMaskConnect' });
    window.close(); // close popup, MetaMask connect page opens in new tab
  });

  // ---- Manual wallet ----
  manualSaveBtn.addEventListener('click', async () => {
    const addr = manualAddr.value.trim();
    if (!addr.match(/^0x[a-fA-F0-9]{40}$/)) {
      manualAddr.style.borderColor = '#ff5252';
      return;
    }
    await chrome.storage.local.set({ walletAddress: addr, walletConnected: true, enabled: true });
    chrome.runtime.sendMessage({ action: 'forceCheck' });
    s = await load();
    render(s);
  });

  // ---- Disconnect ----
  disconnectBtn.addEventListener('click', async () => {
    chrome.runtime.sendMessage({ action: 'disconnect' });
    s = await load();
    setTimeout(async () => { s = await load(); render(s); }, 200);
  });

  // ---- Toggles ----
  togEnabled.addEventListener('change', () => {
    save({ enabled: togEnabled.checked });
    updatePill(togEnabled.checked);
  });
  togAutoRedeem.addEventListener('change', () => save({ autoRedeem: togAutoRedeem.checked }));
  togNotify.addEventListener('change', () => save({ notifications: togNotify.checked }));

  // ---- Actions ----
  redeemBtn.addEventListener('click', () => {
    redeemBtn.textContent = 'Opening PM...';
    redeemBtn.disabled = true;
    chrome.runtime.sendMessage({ action: 'triggerRedeem' });
    setTimeout(() => { redeemBtn.textContent = 'Redeem All'; redeemBtn.disabled = false; }, 8000);
  });

  checkBtn.addEventListener('click', async () => {
    checkBtn.textContent = 'Checking...';
    checkBtn.disabled = true;
    chrome.runtime.sendMessage({ action: 'forceCheck' });
    setTimeout(async () => {
      checkBtn.textContent = 'Check Now';
      checkBtn.disabled = false;
      render(await load());
    }, 5000);
  });

  // ---- Live updates ----
  chrome.storage.onChanged.addListener(async () => render(await load()));

  // ======== Render ========
  function render(d) {
    const hasWallet = d.walletAddress && d.walletAddress.length > 10;

    notConnected.classList.toggle('hidden', hasWallet);
    connected.classList.toggle('hidden', !hasWallet);

    if (!hasWallet) return;

    // Wallet display
    const a = d.walletAddress;
    walletDisplay.textContent = `${a.slice(0, 6)}...${a.slice(-4)}`;
    walletDisplay.title = a;

    // Status
    updatePill(d.enabled !== false);

    // Stats
    totalPos.textContent = d.totalPositions || d.allPositions?.length || '—';
    redeemCnt.textContent = d.redeemableCount || 0;
    redeemVal.textContent = `$${(d.redeemableTotalValue || 0).toFixed(2)}`;
    redeemBtn.disabled = !(d.redeemableCount > 0);

    // Toggles
    togEnabled.checked = d.enabled !== false;
    togAutoRedeem.checked = d.autoRedeem === true;
    togNotify.checked = d.notifications !== false;

    // Positions
    renderPositions(d.positions || []);
    renderHistory(d.redeemHistory || []);
    lastChecked.textContent = d.lastChecked ? timeAgo(d.lastChecked) : 'never';
    if (d.lastError) { lastChecked.textContent += ' ⚠'; lastChecked.title = d.lastError; }
  }

  function updatePill(on) {
    statusPill.className = 'pill ' + (on ? 'on' : 'off');
    statusText.textContent = on ? 'Active' : 'Off';
  }

  function renderPositions(positions) {
    if (!positions.length) {
      posList.innerHTML = '<div class="empty"><div class="empty-ico">📡</div><div class="empty-t">No redeemable positions</div><div class="empty-d">We'll keep checking in the background and notify you when winnings are ready.</div></div>';
      return;
    }
    posList.innerHTML = positions.map(p => `
      <div class="li" title="${esc(p.marketTitle || p.marketName || '')}">
        <div class="li-name">${esc(p.marketTitle || p.marketName || 'Unknown')}</div>
        <div class="li-val">$${(p.payout || p.value || p.size || 0).toFixed(2)}</div>
      </div>
    `).join('');
  }

  function renderHistory(h) {
    if (!h?.length) { histSection.classList.add('hidden'); return; }
    histSection.classList.remove('hidden');
    histList.innerHTML = h.slice(0, 10).map(x => `
      <div class="li">
        <div><div class="li-name">${esc(x.market || 'Unknown')}</div><div class="li-time">${timeAgo(x.timestamp)}</div></div>
        <div class="li-val ${x.status === 'error' ? 'fail' : ''}">${x.status === 'error' ? '✗' : `+$${(x.value || 0).toFixed(2)}`}</div>
      </div>
    `).join('');
  }

  // ======== Util ========
  function esc(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
  function timeAgo(ts) {
    if (!ts) return '—';
    const s = (Date.now() - ts) / 1000;
    if (s < 60) return 'just now';
    if (s < 3600) return `${Math.floor(s/60)}m ago`;
    if (s < 86400) return `${Math.floor(s/3600)}h ago`;
    return `${Math.floor(s/86400)}d ago`;
  }
  function load() { return new Promise(r => chrome.storage.local.get(null, d => r(d || {}))); }
  function save(o) { return chrome.storage.local.set(o); }
});
